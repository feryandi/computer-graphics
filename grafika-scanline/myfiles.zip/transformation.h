void translateList(int distanceX, int distanceY, int list[], int length);
int* rotateList(int degree, int centerX, int centerY, int *list, int length);
void scaleList(int scale, int centerX, int centerY, int list[], int length);